/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SchedulingApplication;

/**
 *
 * @author clply_000
 */
public class SchedulingApplication {
   


        
      
//    private Intializable replaceScene(String fxml) throws Exception {
//        FXMLLoader loader = new FXMLLoader();
//        InputStream in = Main.class.getResourceAsStream(fxml);
//        loader.setBuilderFactory(new JavaFXBuilderFactory());
//        loader.setLocation(Main.class.getResource(fxml));
//        AnchorPane page;
//        try {
//            page = (AnchorPane) loader.load(in);
//        } finally {
//            in.close();
//        } 
//        Scene scene = new Scene(page, 800, 600);
//        stage.setScene(scene);
//        stage.sizeToScene();
//        return (Initializable) loader.getController();
//    }
//    @Override
//    public void start(Stage primaryStage) {
//        Button btn = new Button();
//        btn.setText("Say 'Hello World'");
//        btn.setOnAction(new EventHandler<ActionEvent>() {
//            
//            @Override
//            public void handle(ActionEvent event) {
//                System.out.println("Hello World!");
//            }
//        });
//        
//        StackPane root = new StackPane();
//        root.getChildren().add(btn);
//        
//        Scene scene = new Scene(root, 300, 250);
//        
//        primaryStage.setTitle("Hello World!");
//        primaryStage.setScene(scene);
//        primaryStage.show();
//    }
    
}
